<?php

header("Location: https://appdoc.lanzous.com/b07ra5ubg"); 
file_put_contents("download/downloadnum",file_get_contents("download/downloadnum")+1);

?>