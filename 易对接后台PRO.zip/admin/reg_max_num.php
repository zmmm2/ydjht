<?php
$reg_max_num = 100;
?>